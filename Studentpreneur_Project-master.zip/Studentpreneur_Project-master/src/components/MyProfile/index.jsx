import React from 'react';
// import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';



function MyProfile() {
  return (
    <h1>Its profile</h1>
  );
}

export default MyProfile;
