import React from 'react';
// import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';



function Discussions() {
  return (
    <h1>Its Discussions</h1>
  );
}

export default Discussions;
