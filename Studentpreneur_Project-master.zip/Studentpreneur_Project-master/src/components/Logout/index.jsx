import React from 'react';
// import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';



function Logout() {
  return (
    <h1>Its Logout</h1>
  );
}

export default Logout;
