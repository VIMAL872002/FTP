import React from 'react';
// import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';



function Innovaideas() {
  return (
    <h1>Its Innovaideas</h1>
  );
}

export default Innovaideas;
